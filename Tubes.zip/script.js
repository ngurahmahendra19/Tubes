function toogleSidebar() {
    const side = document.querySelector('#app .sidebar');
    side.classList.toggle('sidebar-hide');
}